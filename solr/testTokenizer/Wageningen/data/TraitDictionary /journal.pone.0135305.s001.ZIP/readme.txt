readme file for plant gene normalization annotation. 01/16/2015

The plant gene normalization results are available in two files. 
One is in BioC format, the other is in excel.

Please note:
This corpos is only for plant gene normalization atabstract level, 
but some annotations are made with beyond abstract information applied,
please check the notes in the excel file for details.
